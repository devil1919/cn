import socket
import sys

def getSelfIP():
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.connect(('8.8.8.8',80))
	return sock.getsockname()[0]

port = 700
print('-'*100)
print(" CHATROOM SERVER \t\t\t\t\t\t| IP : {0} | PORT : {1}".format(getSelfIP(),port)) 
print('-'*100)

s = socket.socket()
s.bind(('',port))
s.listen(5)

while True:
	c, addr = s.accept()
	print("{ip} :> {ms}".format(ip=addr[0],ms=c.recv(2048).decode()))
	msg = input('YOU :> ')
	if msg=='shutdown':
		c.close()
		break;
	c.send(msg.encode())

c.close()
