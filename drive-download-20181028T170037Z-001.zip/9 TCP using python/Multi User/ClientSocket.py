import socket
import os
def getSelfIP():
    sampleSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sampleSocket.connect(('8.8.8.8',80))
    return sampleSocket.getsockname()[0]

print('-'*150)
print(" CHATROOM CLIENT | IP : {}".format(getSelfIP()))
print('-'*150)
hostIP = input(' Enter Server Address : ')
portNO = input(' Enter Port No : ')
os.system('cls')
print('-'*150)
print(" CHATROOM CLIENT | IP : {0} \t\t| HOST[SERVER] IP : {1} | HOST PORT : {2}".format(getSelfIP(),hostIP,portNO))
print('-'*150)

while True :
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect((hostIP,int(portNO)))
    msg = input('MESSAGE > ')
    if msg=='exit':
        break;
    else:
        s.send(msg.encode())
    print("Server > {}".format(s.recv(1024).decode()))

s.close()

