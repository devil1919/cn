import socket
import sys

try:
	s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	print("Socket Created Successfully")
except socket.error as er:
	print("Unable to Create socket \n Error : %s"%(er))

port = 80

try:
	host_ip = socket.gethostbyaddr('www.google.com')
except socket.gaierror as er:
	print("Error in Connection \n Error : %s"%(er))
	sys.exit()
except socket.herror as er:
	print("Unable to Locate Host \n Error : %s"%(er))
	sys.exit()

s.connect((host_ip,port))

print("Connected to IP : %s"%(host_ip))
print("Connected to PORT : %s"%(port))
