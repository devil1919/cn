#include<stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
    int fd,ch;
	
    char * myfifo = "/tmp/myfifo";

    /* create the FIFO (named pipe) */
    mkfifo(myfifo, 0666);
		printf("\n Enter your choise \n");
		printf("\n 1.Charasters separated by space \n");
		printf("\n 2.One string at a time \n");
		printf("\n 3.One sentence at a time \n");
	scanf("%d",&ch);
    /* write "Hi" to the FIFO */
    fd = open(myfifo, O_WRONLY);
   switch(ch)
{
	case 1:
    write(fd, "H i", sizeof("H i"));
 	
	break;
	close(fd);
	unlink(myfifo);
	
	case 2:
   write(fd, "thisisstring", sizeof("thisisstring"));
    		close(fd);
		unlink(myfifo);
		break;
		case 3:
   write(fd, "this is ssntence", sizeof("this is ssntence"));
    		close(fd);
		unlink(myfifo);
		break;


 }   /* remove the FIFO */
//    unlink(myfifo);

    return 0;
}
